package com.mercarbarato.miprimerproyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
private EditText edtNombre;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtNombre = (EditText)findViewById(R.id.edtNombre);
    }

    //Metodo para navegar entre actividades(me lleve al activity calculadora)

    public void Continuar(View view){
        Intent avanzar = new Intent(this, calculadora.class);
        avanzar.putExtra("dato",edtNombre.getText().toString());
        startActivity(avanzar);

    }


}