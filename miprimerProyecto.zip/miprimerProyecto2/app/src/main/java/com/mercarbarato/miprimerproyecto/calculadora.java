package com.mercarbarato.miprimerproyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class calculadora extends AppCompatActivity {
private TextView tv1; //muestra el nombre del usuario;
    private EditText edt1, edt2;
    // captura los numeros de entrada
    private TextView tv3; //variable que me muestra el resultado
    private Button btnBorra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);
        tv1 = (TextView)findViewById(R.id.tv1);
        String dato = getIntent().getStringExtra( "dato");
        tv1.setText("Hola: " + dato);
        edt1 = (EditText) findViewById(R.id.edt1);
        edt2 = (EditText) findViewById(R.id.edt2);
        tv3 = (TextView) findViewById(R.id.tv3);
        btnBorra = (Button) findViewById(R.id.btnBorrar);



    }
    public void Regresar(View view){
        Intent atraz = new Intent(this, MainActivity.class);
        startActivity(atraz);
    }

    public  void Sumar(View view){
        String valor1 = edt1.getText().toString();
        String valor2 = edt2.getText().toString();
        double nro1 = Double.parseDouble(valor1);
        double nro2 = Double.parseDouble(valor2);
        double suma = nro1 + nro2;
        String resul = String.valueOf(suma);
        tv3.setText(resul);



    }




    public  void Restar(View view){
        String valor1 = edt1.getText().toString();
        String valor2 = edt2.getText().toString();

        double nro1 = Double.parseDouble(valor1);
        double nro2 = Double.parseDouble(valor2);
        double resta = nro1 - nro2;
        String resul = String.valueOf(resta);
        tv3.setText(resul);
    }

    public  void Multiplicar(View view){
        String valor1 = edt1.getText().toString();
        String valor2 = edt2.getText().toString();

        double nro1 = Double.parseDouble(valor1);
        double nro2 = Double.parseDouble(valor2);
        double multi = nro1 * nro2;
        String resul = String.valueOf(multi);
        tv3.setText(resul);
    }

    public  void Divi(View view){
        String valor1 = edt1.getText().toString();
        String valor2 = edt2.getText().toString();

        double nro1 = Double.parseDouble(valor1);
        double nro2 = Double.parseDouble(valor2);
        double divi = nro1 / nro2;
        String resul = String.valueOf(divi);
        tv3.setText(resul);
    }

    public void Borrar(View view){
        edt1.setText("");
        edt2.setText("");
        tv3.setText("");


    }


}